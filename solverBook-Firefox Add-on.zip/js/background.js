var service= browser.runtime.connect({name:"port-from-cs"});

service.postMessage({location: document.URL});